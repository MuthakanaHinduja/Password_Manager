---
name: 'General '
about: General issue template
title: ''
labels: bug, documentation, duplicate, enhancement, good first issue, help wanted,
  invalid, question, security issue, wontfix
assignees: ''

---

<h1 align='center'> Label eg:Bug </h1>
<h3 align='center'> title </h3>
  <pr><i>discription</i></pr>
  
  ---
  
  <br>
  <pr><b>about</b></pr>
  <h4>Version: Version x </h4>
  <h4>Python Version: version x </h4>
  <h4>assignees</h4>
  <pr><b>suggestions<b><pr>
